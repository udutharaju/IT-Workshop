<DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,intial-scale">
<title>form Login and register</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="login">
<h1>Login</h1>
<form action="pass_verify.php" method="POST">
<h4>it's free and only a minute</h4>
<form>
    <label>Email</label>
    <input type="email" name="mail" required>
    <label>Password</label>
    <input type="password" name="pass" required>
    <input type="submit" name="submit" value="submit">
    </form>
    <p> Not have an account? <a href="signup.php">sign up
    here</a></p>
    </body>
    </html>